

export type Task = {
    id: number,
    column_id : string,
    title : string,
    desc : string,
    status : string
}